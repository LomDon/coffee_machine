<?php
  $mysqli = mysqli_connect("localhost", "osum2m04_test", "81RkOS*&", "osum2m04_test");
?>