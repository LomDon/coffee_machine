<?php
  session_start();
  $mysqli = new mysqli("localhost", "osum2m04_test", "81RkOS*&", "osum2m04_test");
  $value = $_POST['value'];
  $item = $_POST['item'];
  $userId = $_SESSION['id'];
  $mysqli->query("UPDATE `users` SET `$item`='$value' WHERE `id`='$userId'");
?>