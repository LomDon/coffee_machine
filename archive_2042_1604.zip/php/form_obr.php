<?php
  $tel = $_POST["phone"];
  $msg = $_POST["msg"];
  $isSend = mail("osum2@mail.ru", "ТЕМА ПИСЬМА", "TEL: $tel \n Massage: $msg");
?>