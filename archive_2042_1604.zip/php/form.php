<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Форма для отправки на сервер</title>
  <style>
    div{
      margin:10px;
    }
  </style>
</head>
<body>
  <form onsubmint="sendForm(this); return false;">
    <div>
      <input type="text" name="phone" placeholder="Номер телефона">
    </div>
    <div>
      <textarea name="msg" placeholder="Сообщения"></textarea>
    </div>
    <div>
      <input type="submit">
    </div>
  </form>
  <script>
    async function sendForm(form){
      let formData = new FormData(form);
      let responce = await fetch("form_obr.php",{
        method: "POST",
        body: formData
      });
      let result = await responce.text();
      if(result=="success"){
        alert("Письмо успешно доставлено.");
    }else{
      alert("Ошибка.");
    }
    }
  </script>
  
</body>
</html>