<?php 
$title = "Аутентификация";
$style = "body{
        background-image: url('../../img/fish-fon.jpg');
        background-size: cover;
      }

      form{
        float: left;
        margin-top: 10%;
        margin-left: 40%;
      }
      .form-group{
        font-size:2em;
        color: white;
        font-weight: 700;
        text-shadow: black 1px 1px 0, black -1px -1px 0, 
                     black -1px 1px 0, black 1px -1px 0;
      }
      .form-check{
        color: white;
        font-weight: 700;
        text-shadow: black 1px 1px 0, black -1px -1px 0, 
                     black -1px 1px 0, black 1px -1px 0;
      }
      #form{
        padding:100px;
        border-radius: 10px;
        background: rgba(0, 0, 0, 0.5);
      }
      .link{
        margin-top:50px;
      }
      .bg-wave{
      url('../../img/wave.jpg');
      }
      .container-fluid{
        margin-top:50%;
      }
      .text-box{
        background: rgba(0,0,0,.5);
        border: 2px solid white;
        box-shadow: 5px 5 px 10 px white;
      }";
require_once("header.php"); ?>

  <body>
    <form id="form" onsubmit="sendForm(this); return false;">
      <div class="form-group">
        <label for="exampleInputEmail1">Email</label>
        <input name = "email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Введите email">
      </div>
      <div class="form-group">
        <label for="exampleInputPassword1">Пароль</label>
        <input name = "pass" type="password" class="form-control" id="exampleInputPassword1" placeholder="Введите пароль">
        <p id="info" style="color:red;"></p>
      </div>
      <div class="form-check">
        <input type="checkbox" class="form-check-input" id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Запомнить меня</label>
      </div>
      <button type="submit" class="btn btn-primary">Отправить</button>
      <p class="link"><a href="reg.php">Регистрация</a></p>
    </form>
    <?php require_once("foot.php"); ?>
    <script>
      async function sendForm(form){
        info.innerHTML = '';
        let formData = new FormData(form);
        let response = await fetch("auth_obr.php",{
          method: "POST",
          body: formData
        });
        let result = await response.text();
        if(result=="success"){
          location.href = "lk.php";
        }else
          info.innerHTML = `Логин или пароль введены неверно`;
      }
    </script>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>