          <style><?= $style ?>   </style>
          
    <div class="container-fluid bg-wave py-5">
      <div class="col-sm-5 text-white mx-auto text-box p-3">
        <h3 class="text-center">Перед покупкой</h3>
        <p class="text-center">
          Пожалуйста, уточняйте наличие товара по телефону или лично в нашем магазине.
         </p>
      </div>
    </div>