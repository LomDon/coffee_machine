<?php 
$title = "Контакты";
$style = ".bg-wave{url('../img.wave.jpg');
          }
          .text-box{
            background: rgba(0,0,0,.5);
            border: 2px solid white;
            box-shadow: 5px 5 px 10 px white;
          }";
require_once("php/header.php");?>

    <!-- Контакты -->
    <div class="container py-5">
      <h1 class="text-center">Для связи с нами:</h1>
      <div class="row mt-5">
        <div class="col-md-4">
          <h5>Адрес:</h5>
          <p>г. Москва, ул. Пушкина д.5</p>
          <h5>Телефон:</h5>
          <p>+7(495)123-45-67</p>
          <h5>Время работы:</h5>
          <p>
            Пн.-Пт.: с 10:00 до 22:00<br>
            Сб.-Вс.: Выходной.
          </p>
        </div>
        <div class="col-md-8">
          <form>
            <div class="form-group">
            <input type="text" class="form-control">
            </div>
            <div class="form-group">
            <input type="text" class="form-control">
            </div>
            <div class="form-group">
            <textarea class="form-control"></textarea>
            </div>
            <div class="form-group">
            <input type="submit" class=:form-control btn btn-primary>
            </div>
          </form>
        </div>
      </div>
    </div>
    <!-- Конец контактов -->
    <?php require_once("php/foot.php") ?>
    <!-- Карта -->
    <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3Ac9cb678cc3bd0eaa291e574340279ac4ccd1ea2d66b6ed5f07df8889e625c2fc&amp;width=100%25&amp;height=399&amp;lang=ru_RU&amp;scroll=true"></script>
    <!-- Конец карты -->
    

    <footer class="container p-5 text-center">
      <p>&copy; 2020 веб-программирование группа 0994, Студент Козлитин.</p>
    </footer>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>